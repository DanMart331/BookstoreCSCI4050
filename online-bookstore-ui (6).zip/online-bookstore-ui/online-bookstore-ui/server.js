const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const stripe = require('stripe')('sk_test_51Rel5jP9fb1HIuhDGs6PZ1HR9ui4eK0I8VKXlmeNFdAdGQRujVrxRJUVftIkDopj2Oxfw0Y9xthbm0qkA3YgHd7600FCNBcZqJ');

const app = express();
const PORT = process.env.PORT || 3001;
const db = new sqlite3.Database('./books.db');

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname))); // serves everything in root
app.use('/assets', express.static(path.join(__dirname, 'assets'))); // serves images


// API: Get all books
app.get('/api/books', (req, res) => {
  db.all('SELECT * FROM books', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to retrieve books' });
    res.json({ items: rows });
  });
});

// API: Get book by ID
app.get('/api/books/:id', (req, res) => {
  const bookId = req.params.id;
  db.get('SELECT * FROM books WHERE rowid = ?', [bookId], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed to retrieve book' });
    if (!row) return res.status(404).json({ error: 'Book not found' });
    res.json(row);
  });
});

// Stripe Payments Endpoint
app.post('/api/payments/create-intent', async (req, res) => {
  try {
    const { amount } = req.body;
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount),
      currency: 'usd',
    });
    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    console.error('Payment Error:', error);
    res.status(500).json({ error: 'Payment failed' });
  }
});

// Fallback only for client routes (avoids path-to-regexp crash)
app.get(/^\/(?!api).*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
