// DOM Elements
const apiStatusElement = document.getElementById('apiStatus');
const apiErrorModal = document.getElementById('apiErrorModal');
const apiErrorText = document.getElementById('apiErrorText');

// Load books with local images only
async function loadBooks(sectionId, type = 'featured', enableCart = false) {
  const container = document.getElementById(sectionId);
  if (!container) return;

  showLoading(container, 'Loading...');

  let books = [];

  if (type === 'featured') {
    books = [
      {
        id: 'b1',
        title: 'Broken Country',
        author: 'Clare',
        price: 12.5,
        image: 'assets/book_images/broken_country.jpg',
        description: 'A gripping mystery set in rural England.'
      }
    ];
  } else if (type === 'coming-soon') {
    books = [
      {
        id: 'b2',
        title: 'Onyx Storm',
        author: 'Rebecca Yarros',
        price: 13.99,
        image: 'assets/book_images/onyx_storm.jpg',
        description: 'The next thrilling installment in the Empyrean series.'
      },
      {
        id: 'b3',
        title: 'Sunrise on the Reaping',
        author: 'Suzanne Collins',
        price: 14.99,
        image: 'assets/book_images/sunrise_reaping.jpg',
        description: 'A new Hunger Games novel.'
      }
    ];
  }

  updateApiStatus(`Showing ${books.length} book(s)`);
  renderBooks(container, books, enableCart);
}

// Render books
function renderBooks(container, books = [], enableCart) {
  container.innerHTML = '';

  if (!books.length) {
    container.innerHTML = '<p class="no-results">No books found</p>';
    return;
  }

  books.forEach(book => {
    const el = document.createElement('div');
    el.className = 'book';
    el.innerHTML = `
      <img src="${book.image}" alt="${book.title}" onclick="viewBookDetails('${book.id}')">
      <h3 onclick="viewBookDetails('${book.id}')">${book.title}</h3>
      <p class="author">by ${book.author}</p>
      <p class="price">$${book.price.toFixed(2)}</p>
      ${enableCart ? `<button onclick="addToCart('${book.id}')">Add to Cart</button>` : ''}
    `;
    container.appendChild(el);
  });
}

// Helpers
function showLoading(container, message = 'Loading...') {
  container.innerHTML = `<div class="loading">${message}</div>`;
}

function updateApiStatus(message, isError = false) {
  if (!apiStatusElement) return;
  apiStatusElement.textContent = message;
  apiStatusElement.className = isError ? 'error' : '';
}

function showApiError(message) {
  if (!apiErrorModal || !apiErrorText) return;
  apiErrorText.textContent = message;
  apiErrorModal.style.display = 'block';
}

// Navigation
function updateNav() {
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  const loginLink = document.getElementById('loginLink');
  const profileLink = document.getElementById('profileLink');

  if (user) {
    if (loginLink) loginLink.style.display = 'none';
    if (profileLink) {
      profileLink.style.display = 'inline';
      profileLink.textContent = user.name || 'Profile';
    }
  } else {
    if (loginLink) loginLink.style.display = 'inline';
    if (profileLink) profileLink.style.display = 'none';
  }

  updateCartCount();
}

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart') || '[]');
  const totalItems = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);
  const cartCountElement = document.getElementById('cartCount');
  if (cartCountElement) cartCountElement.textContent = totalItems;
}

function viewBookDetails(bookId) {
  window.location.href = `book_details.html?id=${bookId}`;
}

// Toast feedback
function showToast(message, isError = false) {
  const toast = document.createElement('div');
  toast.className = `toast ${isError ? 'error' : ''}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
