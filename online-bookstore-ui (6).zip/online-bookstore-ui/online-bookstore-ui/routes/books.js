const express = require('express');
const router = express.Router();
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./books.db');

// Get all featured books
router.get('/featured', (req, res) => {
  db.all("SELECT * FROM books WHERE featured = 1", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ items: rows });
  });
});

// Get coming soon books
router.get('/coming-soon', (req, res) => {
  db.all("SELECT * FROM books WHERE coming_soon = 1", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ items: rows });
  });
});

// Search books
router.get('/search', (req, res) => {
  const { term, genre } = req.query;
  let query = "SELECT * FROM books WHERE 1=1";
  let params = [];

  if (term) {
    query += " AND title LIKE ?";
    params.push(`%${term}%`);
  }

  if (genre && genre !== 'All') {
    query += " AND genre = ?";
    params.push(genre);
  }

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ items: rows });
  });
});

// Book details
router.get('/:id', (req, res) => {
  const { id } = req.params;
  db.get("SELECT * FROM books WHERE id = ?", [id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(row);
  });
});

module.exports = router;
