const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const jwt = require('jsonwebtoken');

const db = new sqlite3.Database('./books.db');
const SECRET_KEY = 'your_secret_key'; // Replace with env var in production

// Register
router.post('/register', (req, res) => {
  const { name, email, password } = req.body;
  const hashed = bcrypt.hashSync(password, 10);

  db.run(
    'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
    [name, email, hashed],
    function (err) {
      if (err) {
        console.error(err);
        return res.status(400).json({ error: 'Registration failed' });
      }
      res.json({ success: true, id: this.lastID });
    }
  );
});

// Login
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  db.get('SELECT * FROM users WHERE email = ?', [email], (err, user) => {
    if (err || !user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user.id, name: user.name, isAdmin: !!user.is_admin }, SECRET_KEY, {
      expiresIn: '1h',
    });

    res.json({ token, name: user.name });
  });
});

module.exports = router;
